# NevaVis — статус

v1.2.0: проверенная сборка Java 21 / Gradle 8.12; стандартный Minecraft font; масштабируемый постоянный Music HUD; расширенный Target/Combo HUD; Sound category mixer; оконный aspect ratio; обычный Block Overlay; phrase wheel; inventory overview; hotbar/chat/Tab/perspective/totem transitions.

Не реализованы намеренно: Target ESP и FreeLook. Block Overlay изменяет только видимую vanilla selection outline; чит-функции и обходы не добавлялись.
Если музыка не играет: смотри строку ошибки на странице Music и `.minecraft/logs/latest.log`.

v3.2: плащ NevaVis (у владельцев мода), текст песни в небе (.lrc/.txt рядом с треком), иконка мода.

v3.3: Swing Animation (стиль+скорость), Durability Alert, Item Counter HUD. Промпт агента: GITHUB_AGENT_PROMPT.md

v3.4: исходная версия проекта для NevaVis 1.1.0; Custom Fog, drag-and-drop HUD в чате, Target HUD после удара, Kill Counter, World Time.
