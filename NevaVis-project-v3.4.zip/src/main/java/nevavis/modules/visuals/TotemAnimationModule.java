package nevavis.modules.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.Items;
import nevavis.modules.Module;
import nevavis.modules.ModuleCategory;
import nevavis.modules.ModuleManager;
import nevavis.render.Gfx;
import nevavis.themes.ThemeManager;
import nevavis.utils.Colors;

/** Adds a brief local-player overlay when vanilla reports a totem activation. */
public final class TotemAnimationModule extends Module {
	public static final String ID = "totem_animation";
	private static long triggeredAt;

	public TotemAnimationModule() {
		super(ID, "Totem Animation", "Animate the vanilla totem activation", ModuleCategory.ANIMATIONS);
		addSetting("duration", "Duration (ms)", 250f, 1400f, 50f, 700f);
		addSetting("scale", "Pop scale", 0.8f, 2.2f, 0.1f, 1.6f);
	}

	public static void trigger() {
		Module module = ModuleManager.byId(ID);
		if (module instanceof TotemAnimationModule animation && animation.isEnabled()) {
			triggeredAt = System.currentTimeMillis();
		}
	}

	@Override
	public void onHud(DrawContext context, MinecraftClient client, float tickDelta) {
		long elapsed = System.currentTimeMillis() - triggeredAt;
		float duration = get("duration");
		if (triggeredAt == 0L || elapsed < 0L || elapsed >= duration) {
			return;
		}
		float progress = elapsed / duration;
		float fade = 1f - progress;
		float scale = get("scale") * (1f - 0.35f * progress);
		int centerX = context.getScaledWindowWidth() / 2;
		int centerY = context.getScaledWindowHeight() / 2;
		var matrices = context.getMatrices();
		matrices.push();
		matrices.translate(centerX, centerY - 16f * fade, 0f);
		matrices.scale(scale, scale, 1f);
		Gfx.setFade(fade);
		Gfx.roundedOutline(context, -18, -18, 36, 36, 9, Gfx.accent(fade));
		context.drawItem(Items.TOTEM_OF_UNDYING.getDefaultStack(), -8, -8);
		Gfx.centered(context, "TOTEM SAVED", 0, 25, Colors.withAlpha(ThemeManager.text(), fade));
		Gfx.setFade(1f);
		matrices.pop();
	}
}