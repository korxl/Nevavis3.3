package nevavis.modules.visuals;

import nevavis.modules.Module;
import nevavis.modules.ModuleCategory;
import nevavis.modules.ModuleManager;
import nevavis.utils.Colors;

/** Customizes the ordinary outline of the block currently selected by vanilla targeting. */
public final class BlockOverlayModule extends Module {
	public static final String ID = "block_overlay";

	public BlockOverlayModule() {
		super(ID, "Block Overlay", "Color and animate the selected block outline", ModuleCategory.WORLD);
		addSetting("mode", "Mode (0 Solid, 1 Pulse, 2 Rainbow)", 0f, 2f, 1f, 1f);
		addSetting("hue", "Hue", 0f, 1f, 0.01f, 0.48f);
		addSetting("saturation", "Saturation", 0f, 1f, 0.05f, 0.85f);
		addSetting("opacity", "Opacity", 0.1f, 1f, 0.05f, 0.85f);
		addSetting("speed", "Animation speed", 0.2f, 2f, 0.1f, 1f);
	}

	public static int color(int vanilla) {
		Module module = ModuleManager.byId(ID);
		if (!(module instanceof BlockOverlayModule overlay) || !overlay.isEnabled()) {
			return vanilla;
		}

		int mode = Math.round(overlay.get("mode"));
		float time = System.currentTimeMillis() / 1000f * overlay.get("speed");
		float hue = mode == 2 ? time * 0.12f % 1f : overlay.get("hue");
		float brightness = mode == 1 ? 0.68f + 0.32f * (0.5f + 0.5f * (float) Math.sin(time * 3f)) : 1f;
		int rgb = Colors.hsv(hue, overlay.get("saturation"), brightness);
		int alpha = Math.round(255f * overlay.get("opacity"));
		return alpha << 24 | rgb & 0x00FFFFFF;
	}
}