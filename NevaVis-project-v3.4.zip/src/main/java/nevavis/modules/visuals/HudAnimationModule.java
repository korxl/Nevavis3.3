package nevavis.modules.visuals;

import nevavis.modules.Module;
import nevavis.modules.ModuleCategory;
import nevavis.modules.ModuleManager;

/** Small client-only transitions for vanilla HUD layers. */
public final class HudAnimationModule extends Module {
	public static final String ID = "hud_animations";

	public HudAnimationModule() {
		super(ID, "HUD Animations", "Animate the vanilla hotbar, chat and player list", ModuleCategory.ANIMATIONS);
		addSetting("hotbar", "Hotbar (0 Off, 1 On)", 0f, 1f, 1f, 1f);
		addSetting("chat", "Chat (0 Off, 1 On)", 0f, 1f, 1f, 1f);
		addSetting("tab", "Player list (0 Off, 1 On)", 0f, 1f, 1f, 1f);
		addSetting("perspective", "Perspective transition (0 Off, 1 On)", 0f, 1f, 1f, 1f);
		addSetting("speed", "Transition speed", 0.5f, 2f, 0.1f, 1f);
	}

	public static boolean enabled(String setting) {
		Module module = ModuleManager.byId(ID);
		return module instanceof HudAnimationModule animation && animation.isEnabled() && animation.get(setting) >= 0.5f;
	}

	public static float speed() {
		Module module = ModuleManager.byId(ID);
		return module instanceof HudAnimationModule animation ? animation.get("speed") : 1f;
	}
}