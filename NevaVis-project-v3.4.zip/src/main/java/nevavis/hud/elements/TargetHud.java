package nevavis.hud.elements;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import nevavis.hud.CombatTracker;
import nevavis.hud.HudElement;
import nevavis.render.Gfx;
import nevavis.themes.ThemeManager;
import nevavis.utils.Colors;

/** Target HUD: голова/скин, ник, HP-полоска, броня, комбо и reach последнего удара. */
public final class TargetHud extends HudElement {
	private java.util.UUID animatedTarget;
	private float displayedHealth;

	public TargetHud() {
		super("target", "Target HUD", 0.60f, 0.55f, true);
	}

	@Override
	protected void draw(DrawContext c, MinecraftClient mc) {
		w = 176;
		h = 54;
		LivingEntity t = CombatTracker.target();
		boolean ghost = t == null;
		if (ghost && !ghostMode) {
			return; // появляется только после удара
		}
		background(c, w, h);
		if (ghost) {
			Gfx.text(c, "Target HUD", 8, 10, ThemeManager.dim(), cfg().shadow);
			Gfx.text(c, "Hit someone to see info", 8, 24, ThemeManager.dim(), cfg().shadow);
			return;
		}
		if (!t.getUuid().equals(animatedTarget)) {
			animatedTarget = t.getUuid();
			displayedHealth = t.getHealth();
		} else {
			displayedHealth += (t.getHealth() - displayedHealth) * 0.28f;
		}
		// Player head when available; other entities use a readable initial.
		boolean drawn = false;
		if (t instanceof PlayerEntity p && mc.getNetworkHandler() != null) {
			PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(p.getUuid());
			if (e != null) {
				PlayerSkinDrawer.draw(c, e.getSkinTextures(), 4, 6, 32);
				drawn = true;
			}
		}
		if (!drawn) {
			Gfx.roundedRect(c, 4, 6, 32, 32, 4, Gfx.accent(0.4f));
			String n = t.getName().getString();
			Gfx.centered(c, n.isEmpty() ? "?" : n.substring(0, 1).toUpperCase(), 20, 19, ThemeManager.text());
		}
		Gfx.roundedOutline(c, 3, 5, 34, 34, 5, t.hurtTime > 0 ? 0xFFFF5C65 : Gfx.accent(0.7f));
		Gfx.text(c, Gfx.fit(t.getName().getString(), w - 48), 42, 5, textColor(), cfg().shadow);

		float hp = t.getHealth();
		float max = Math.max(1f, t.getMaxHealth());
		float frac = Math.max(0f, Math.min(1f, displayedHealth / max));
		float absorption = Math.max(0f, t.getAbsorptionAmount());
		int barX = 42, barY = 24, barW = w - 50;
		Gfx.roundedRect(c, barX, barY, barW, 6, 3, Colors.withAlpha(0x000000, 0.55f));
		int col = Colors.lerp(0xEF4444, 0x22C55E, frac);
		int hpWidth = Math.round(barW * frac);
		if (hpWidth > 0) {
			Gfx.roundedGradient(c, barX, barY, hpWidth, 6, 3, 0xFF000000 | col, 0xFF000000 | Colors.lerp(col, 0xFFFFFF, 0.12f));
		}
		int absorptionWidth = Math.min(barW - hpWidth, Math.round(barW * absorption / max));
		if (absorptionWidth > 0) {
			Gfx.roundedRect(c, barX + hpWidth, barY, absorptionWidth, 6, 3, 0xFFFFC857);
		}
		String healthText = String.format("%.1f / %.0f HP%s", hp, max,
				absorption > 0f ? String.format(" + %.1f", absorption) : "");
		Gfx.text(c, Gfx.fit(healthText, barW), barX, 14, textColor(), cfg().shadow);
		Gfx.text(c, "Armor " + t.getArmor(), barX, 36, ThemeManager.dim(), cfg().shadow);
		String reachText = String.format("%.1fm", CombatTracker.reach());
		Gfx.text(c, reachText, barX + 58, 36, ThemeManager.dim(), cfg().shadow);

		int combo = CombatTracker.combo();
		if (combo > 1) {
			String comboText = "x" + combo;
			Gfx.text(c, comboText, w - 6 - Gfx.width(comboText), 36, ThemeManager.accent(), cfg().shadow);
		}
	}
}
