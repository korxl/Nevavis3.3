package nevavis.hud;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.option.Perspective;
import nevavis.modules.visuals.HudAnimationModule;
import nevavis.themes.ThemeManager;
import nevavis.utils.Colors;

/** Applies short matrix-only transitions to vanilla HUD layers. */
public final class HudAnimations {
	private static int selectedSlot = -1;
	private static long hotbarChangedAt;
	private static long chatOpenedAt;
	private static long tabOpenedAt;
	private static long lastTabRenderAt;
	private static long perspectiveChangedAt;
	private static Perspective lastPerspective;
	private static boolean chatWasOpen;

	private HudAnimations() {
	}

	public static void beginHotbar(DrawContext context) {
		var matrices = context.getMatrices();
		matrices.push();
		MinecraftClient client = MinecraftClient.getInstance();
		if (client.player == null || !HudAnimationModule.enabled("hotbar")) {
			return;
		}
		int slot = client.player.getInventory().selectedSlot;
		long now = System.currentTimeMillis();
		if (slot != selectedSlot) {
			selectedSlot = slot;
			hotbarChangedAt = now;
		}
		float progress = progress(now - hotbarChangedAt);
		matrices.translate(0f, (1f - progress) * 5f, 0f);
	}

	public static void beginChat(DrawContext context) {
		var matrices = context.getMatrices();
		matrices.push();
		MinecraftClient client = MinecraftClient.getInstance();
		boolean open = client.currentScreen instanceof ChatScreen;
		long now = System.currentTimeMillis();
		if (open && !chatWasOpen) {
			chatOpenedAt = now;
		}
		chatWasOpen = open;
		if (open && HudAnimationModule.enabled("chat")) {
			matrices.translate(0f, -(1f - progress(now - chatOpenedAt)) * 6f, 0f);
		}
	}

	public static void beginTab(DrawContext context) {
		var matrices = context.getMatrices();
		matrices.push();
		long now = System.currentTimeMillis();
		if (now - lastTabRenderAt > 120) {
			tabOpenedAt = now;
		}
		lastTabRenderAt = now;
		if (HudAnimationModule.enabled("tab")) {
			float progress = progress(now - tabOpenedAt);
			float scale = 0.96f + 0.04f * progress;
			matrices.translate(context.getScaledWindowWidth() / 2f, 0f, 0f);
			matrices.scale(scale, scale, 1f);
			matrices.translate(-context.getScaledWindowWidth() / 2f, 0f, 0f);
		}
	}

	public static void end(DrawContext context) {
		context.getMatrices().pop();
	}

	public static void renderPerspectiveTransition(DrawContext context, MinecraftClient client) {
		Perspective perspective = client.options.getPerspective();
		long now = System.currentTimeMillis();
		if (lastPerspective == null) {
			lastPerspective = perspective;
			return;
		}
		if (perspective != lastPerspective) {
			lastPerspective = perspective;
			perspectiveChangedAt = HudAnimationModule.enabled("perspective") ? now : 0L;
		}
		if (perspectiveChangedAt == 0L) {
			return;
		}
		float progress = (now - perspectiveChangedAt) / 220f;
		if (progress >= 1f) {
			perspectiveChangedAt = 0L;
			return;
		}
		float pulse = (float) Math.sin(Math.max(0f, progress) * Math.PI) * 0.12f;
		context.fill(0, 0, context.getScaledWindowWidth(), context.getScaledWindowHeight(),
				Colors.withAlpha(ThemeManager.accent(), pulse));
	}

	private static float progress(long elapsedMs) {
		float duration = 220f / Math.max(0.25f, HudAnimationModule.speed());
		return Math.max(0f, Math.min(1f, elapsedMs / duration));
	}
}