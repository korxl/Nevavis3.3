package nevavis.gui.screens;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import nevavis.gui.components.SearchBar;
import nevavis.render.Gfx;
import nevavis.themes.ThemeManager;
import nevavis.utils.Colors;

import java.util.Locale;

/** Read-only inventory overview with filtering, slot selection and vanilla item tooltips. */
public final class InventoryPage extends Page {
	private static final int SLOT = 34, GAP = 3, COLUMNS = 9;
	private final SearchBar filter = new SearchBar("Filter items...");
	private int gridX, gridY, selectedSlot = -1;

	public InventoryPage() {
		comps.add(filter);
	}

	@Override
	public String title() {
		return "Inventory Manager";
	}

	@Override
	public void onShow() {
		super.onShow();
		selectedSlot = -1;
	}

	@Override
	protected int reflow(int top) {
		filter.bounds(x, top, w, 20);
		gridX = x + 6;
		gridY = top + 32;
		return gridY + 4 * (SLOT + GAP) + 10;
	}

	@Override
	protected void renderBody(DrawContext context, double mouseX, double mouseY, float delta) {
		MinecraftClient client = MinecraftClient.getInstance();
		if (client.player == null) {
			Gfx.text(context, "Inventory unavailable", x + 6, gridY, ThemeManager.dim());
			return;
		}
		var inventory = client.player.getInventory();
		int matching = 0;
		int occupied = 0;
		int hoveredSlot = -1;
		String query = filter.getText().trim().toLowerCase(Locale.ROOT);

		for (int row = 0; row < 4; row++) {
			for (int column = 0; column < COLUMNS; column++) {
				int slotIndex = row == 3 ? column : 9 + row * COLUMNS + column;
				ItemStack stack = inventory.getStack(slotIndex);
				int slotX = gridX + column * (SLOT + GAP);
				int slotY = gridY + row * (SLOT + GAP);
				boolean present = !stack.isEmpty();
				boolean matches = present && (query.isEmpty() || stack.getName().getString().toLowerCase(Locale.ROOT).contains(query));
				if (present) {
					occupied++;
				}
				if (matches) {
					matching++;
				}
				boolean hovered = mouseX >= slotX && mouseX < slotX + SLOT && mouseY >= slotY && mouseY < slotY + SLOT;
				if (hovered) {
					hoveredSlot = slotIndex;
				}
				int slotBackground = !present ? 0x30000000 : matches ? 0x70505050 : 0x20505050;
				Gfx.roundedRect(context, slotX, slotY, SLOT, SLOT, 4, slotBackground);
				Gfx.roundedOutline(context, slotX, slotY, SLOT, SLOT, 4,
						hovered || selectedSlot == slotIndex ? Gfx.accent(0.9f) : Colors.withAlpha(ThemeManager.dim(), 0.25f));
				if (matches) {
					context.drawItem(stack, slotX + 8, slotY + 7);
					if (stack.getCount() > 1) {
						Gfx.rightAligned(context, Integer.toString(stack.getCount()), slotX + SLOT - 3, slotY + SLOT - 10,
								ThemeManager.text());
					}
				}
			}
		}

		int infoX = gridX + COLUMNS * (SLOT + GAP) + 4;
		Gfx.text(context, "Occupied slots", infoX, gridY + 2, ThemeManager.dim());
		Gfx.text(context, occupied + " / 36", infoX, gridY + 14, ThemeManager.text());
		Gfx.text(context, "Matching stacks", infoX, gridY + 36, ThemeManager.dim());
		Gfx.text(context, Integer.toString(matching), infoX, gridY + 48, ThemeManager.text());
		if (hoveredSlot >= 0) {
			ItemStack stack = inventory.getStack(hoveredSlot);
			if (!stack.isEmpty()) {
				context.drawItemTooltip(client.textRenderer, stack, (int) mouseX, (int) mouseY);
			}
		}
	}

	@Override
	public boolean mouseClicked(double mouseX, double mouseY, int button) {
		if (super.mouseClicked(mouseX, mouseY, button)) {
			return true;
		}
		if (button == 0) {
			for (int row = 0; row < 4; row++) {
				for (int column = 0; column < COLUMNS; column++) {
					int slotX = gridX + column * (SLOT + GAP);
					int slotY = gridY + row * (SLOT + GAP);
					if (mouseX >= slotX && mouseX < slotX + SLOT && mouseY >= slotY && mouseY < slotY + SLOT) {
						selectedSlot = row == 3 ? column : 9 + row * COLUMNS + column;
						return true;
					}
				}
			}
		}
		return false;
	}
}