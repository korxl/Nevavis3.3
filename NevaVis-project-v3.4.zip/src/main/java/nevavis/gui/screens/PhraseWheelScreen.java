package nevavis.gui.screens;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import nevavis.config.ConfigManager;
import nevavis.render.Gfx;
import nevavis.themes.ThemeManager;
import nevavis.utils.Colors;
import org.lwjgl.glfw.GLFW;

import java.util.List;

/** Radial picker that sends only the phrase selected by the player. */
public final class PhraseWheelScreen extends Screen {
	private static final int BUTTON_W = 100;
	private static final int BUTTON_H = 24;
	private static final double TAU = Math.PI * 2.0;

	public PhraseWheelScreen() {
		super(Text.literal("Phrase Wheel"));
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		context.fill(0, 0, width, height, 0x9906070B);
		List<String> phrases = ConfigManager.get().data().quickPhrases;
		int centerX = width / 2;
		int centerY = height / 2;
		int radiusX = Math.min(118, width / 3);
		int radiusY = Math.min(82, height / 3);

		for (int i = 0; i < Math.min(8, phrases.size()); i++) {
			double angle = -Math.PI / 2.0 + i * TAU / 8.0;
			int buttonX = centerX + (int) Math.round(Math.cos(angle) * radiusX) - BUTTON_W / 2;
			int buttonY = centerY + (int) Math.round(Math.sin(angle) * radiusY) - BUTTON_H / 2;
			boolean hovered = mouseX >= buttonX && mouseX < buttonX + BUTTON_W
					&& mouseY >= buttonY && mouseY < buttonY + BUTTON_H;
			int background = hovered ? Gfx.accent(0.9f) : Gfx.surface(0.92f);
			Gfx.roundedRect(context, buttonX, buttonY, BUTTON_W, BUTTON_H, 8, background);
			Gfx.roundedOutline(context, buttonX, buttonY, BUTTON_W, BUTTON_H, 8, Gfx.accent(hovered ? 1f : 0.45f));
			String phrase = phrases.get(i).isBlank() ? "Phrase " + (i + 1) : phrases.get(i);
			Gfx.centered(context, Gfx.fit(phrase, BUTTON_W - 12), buttonX + BUTTON_W / 2,
					buttonY + 8, ThemeManager.text());
		}

		String title = "Phrase Wheel";
		Gfx.centered(context, title, centerX, centerY - 4, Colors.withAlpha(ThemeManager.text(), 0.9f));
	}

	@Override
	public boolean mouseClicked(double mouseX, double mouseY, int button) {
		if (button == 0) {
			List<String> phrases = ConfigManager.get().data().quickPhrases;
			int centerX = width / 2;
			int centerY = height / 2;
			int radiusX = Math.min(118, width / 3);
			int radiusY = Math.min(82, height / 3);
			for (int i = 0; i < Math.min(8, phrases.size()); i++) {
				double angle = -Math.PI / 2.0 + i * TAU / 8.0;
				int buttonX = centerX + (int) Math.round(Math.cos(angle) * radiusX) - BUTTON_W / 2;
				int buttonY = centerY + (int) Math.round(Math.sin(angle) * radiusY) - BUTTON_H / 2;
				if (mouseX >= buttonX && mouseX < buttonX + BUTTON_W
						&& mouseY >= buttonY && mouseY < buttonY + BUTTON_H) {
					send(phrases.get(i));
					return true;
				}
			}
		}
		return super.mouseClicked(mouseX, mouseY, button);
	}

	@Override
	public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
		if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
			close();
			return true;
		}
		int index = keyCode - GLFW.GLFW_KEY_1;
		List<String> phrases = ConfigManager.get().data().quickPhrases;
		if (index >= 0 && index < Math.min(8, phrases.size())) {
			send(phrases.get(index));
			return true;
		}
		return super.keyPressed(keyCode, scanCode, modifiers);
	}

	private void send(String phrase) {
		MinecraftClient client = MinecraftClient.getInstance();
		String message = phrase == null ? "" : phrase.trim();
		if (!message.isEmpty() && client.player != null && client.player.networkHandler != null) {
			client.player.networkHandler.sendChatMessage(message);
		}
		close();
	}
}