package nevavis.gui.screens;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.sound.SoundCategory;
import nevavis.config.ConfigManager;
import nevavis.config.NevaVisConfig;
import nevavis.gui.components.Button;
import nevavis.gui.components.Dropdown;
import nevavis.gui.components.KeybindSelector;
import nevavis.gui.components.SearchBar;
import nevavis.gui.components.Slider;
import nevavis.gui.components.Tabs;
import nevavis.gui.components.Toggle;
import nevavis.keybinds.KeybindManager;
import nevavis.notifications.NotificationManager;
import nevavis.render.Gfx;
import nevavis.render.Icons;
import nevavis.themes.ThemeManager;

import java.util.ArrayList;
import java.util.List;

/** Настройки интерфейса и клавиши. */
public final class SettingsPage extends Page {
	private final Tabs tabs;
	private int tab;
	private final Slider guiScale, animSpeed, glow, transparency, radius;
	private final Toggle guiAnim, glowOn, lowPerf, fpsOpt, notif, presOn, badgeOn, capeOn, lyricsOn;
	private final Slider hudScale, musicVol, notifSec;
	private final SearchBar url = new SearchBar("https://your-worker.workers.dev", 96);
	private final SearchBar windowWidth, windowHeight;
	private final Dropdown aspectRatio;
	private final Button applyResolution;
	private final List<Slider> soundSliders = new ArrayList<>();
	private final Button reset;
	private final KeybindSelector openKey, phraseKey;
	private final List<SearchBar> phraseFields = new ArrayList<>();
	private String selectedAspect = "Native";

	public SettingsPage() {
		NevaVisConfig cfg = ConfigManager.get().data();
		tabs = new Tabs(List.of("Interface", "Display", "Online", "Keys", "Sound"), i -> {
			tab = i;
			rebuild();
			scroll.reset();
		});
		guiScale = new Slider("GUI Scale", 0.6f, 1.5f, 0.05f, () -> cfg.guiScale, v -> cfg.guiScale = v, "%.2fx");
		animSpeed = new Slider("Animation Speed", 0.25f, 3f, 0.05f, () -> cfg.animationSpeed, v -> cfg.animationSpeed = v, "%.2fx");
		glow = new Slider("Glow Intensity", 0f, 2f, 0.05f, () -> cfg.glowIntensity, v -> cfg.glowIntensity = v, "%.2f");
		transparency = new Slider("Transparency", 0.3f, 1f, 0.05f, () -> cfg.transparency, v -> cfg.transparency = v, "%.2f");
		radius = new Slider("Corner Radius", 0f, 14f, 1f, () -> (float) cfg.cornerRadius, v -> cfg.cornerRadius = v.intValue(), "%.0f px");
		guiAnim = new Toggle("GUI animations", () -> cfg.guiAnimations, v -> cfg.guiAnimations = v);
		glowOn = new Toggle("Glow effects", () -> cfg.glowEnabled, v -> cfg.glowEnabled = v);
		lowPerf = new Toggle("Low performance mode", () -> cfg.lowPerformance, v -> cfg.lowPerformance = v);
		lowPerf.tooltip("Disables glow rings to save FPS");
		fpsOpt = new Toggle("FPS optimization", () -> cfg.fpsOptimization, v -> cfg.fpsOptimization = v);
		notif = new Toggle("Notifications", () -> cfg.notifications, v -> cfg.notifications = v);
		hudScale = new Slider("HUD Scale", 0.5f, 2f, 0.05f, () -> cfg.hudScale, v -> cfg.hudScale = v, "%.2fx");
		notifSec = new Slider("Notification time", 1f, 8f, 0.5f, () -> cfg.notificationSeconds, v -> cfg.notificationSeconds = v, "%.1f s");
		musicVol = new Slider("Music volume", 0f, 1f, 0.05f, () -> nevavis.music.MusicPlayer.get().volume(), v -> nevavis.music.MusicPlayer.get().setVolume(v), "%.2f");
		presOn = new Toggle("Online counter (presence)", () -> cfg.presenceEnabled, v -> { cfg.presenceEnabled = v; nevavis.presence.PresenceManager.resetTimer(); });
		badgeOn = new Toggle("Show N badge on nametags", () -> cfg.showBadge, v -> cfg.showBadge = v);
		capeOn = new Toggle("NevaVis cape (for mod users)", () -> cfg.showCape, v -> cfg.showCape = v);
		lyricsOn = new Toggle("Lyrics in the sky (.lrc / .txt next to track)", () -> cfg.skyLyrics, v -> cfg.skyLyrics = v);
		var window = MinecraftClient.getInstance().getWindow();
		windowWidth = new SearchBar("Width (px)", 5);
		windowHeight = new SearchBar("Height (px)", 5);
		windowWidth.setText(Integer.toString(window.getWidth()));
		windowHeight.setText(Integer.toString(window.getHeight()));
		aspectRatio = new Dropdown("Aspect ratio", List.of("Native", "16:9", "4:3", "21:9", "Custom"),
				() -> selectedAspect, value -> {
					selectedAspect = value;
					setAspectPreset(value);
				});
		applyResolution = new Button("Apply window size", this::applyWindowSize);
		for (SoundCategory category : new SoundCategory[]{SoundCategory.MASTER, SoundCategory.MUSIC,
				SoundCategory.RECORDS, SoundCategory.WEATHER, SoundCategory.BLOCKS, SoundCategory.HOSTILE,
				SoundCategory.NEUTRAL, SoundCategory.PLAYERS, SoundCategory.AMBIENT, SoundCategory.VOICE}) {
			String label = switch (category) {
				case MASTER -> "Master";
				case MUSIC -> "Music";
				case RECORDS -> "Music discs";
				case WEATHER -> "Weather";
				case BLOCKS -> "Blocks";
				case HOSTILE -> "Hostile";
				case NEUTRAL -> "Neutral";
				case PLAYERS -> "Players";
				case AMBIENT -> "Ambient";
				case VOICE -> "Voice / UI";
			};
			soundSliders.add(new Slider(label, 0f, 100f, 1f,
					() -> MinecraftClient.getInstance().options.getSoundVolume(category) * 100f,
					value -> MinecraftClient.getInstance().options.getSoundVolumeOption(category).setValue((double) (value / 100f)),
					"%.0f%%"));
		}
		url.setText(cfg.presenceUrl);
		reset = new Button("Reset to defaults", () -> {
			cfg.resetInterface();
			ThemeManager.applyByName(cfg.theme);
			ConfigManager.get().noteChange("Settings reset to defaults");
		});
		openKey = new KeybindSelector("Open NevaVis GUI", KeybindManager.openGui());
		phraseKey = new KeybindSelector("Open phrase wheel", KeybindManager.phraseWheel());
		while (cfg.quickPhrases.size() < 8) {
			cfg.quickPhrases.add("");
		}
		for (int i = 0; i < 8; i++) {
			SearchBar field = new SearchBar("Phrase " + (i + 1), 64);
			field.setText(cfg.quickPhrases.get(i));
			phraseFields.add(field);
		}
		rebuild();
	}

	private void rebuild() {
		comps.clear();
		comps.add(tabs);
		if (tab == 0) {
			comps.add(guiScale);
			comps.add(animSpeed);
			comps.add(glow);
			comps.add(transparency);
			comps.add(radius);
			comps.add(guiAnim);
			comps.add(glowOn);
			comps.add(lowPerf);
			comps.add(fpsOpt);
			comps.add(notif);
			comps.add(lyricsOn);
			comps.add(hudScale);
			comps.add(notifSec);
			comps.add(musicVol);
			comps.add(reset);
		} else if (tab == 1) {
			comps.add(aspectRatio);
			comps.add(windowWidth);
			comps.add(windowHeight);
			comps.add(applyResolution);
		} else if (tab == 2) {
			comps.add(presOn);
			comps.add(badgeOn);
			comps.add(capeOn);
			comps.add(url);
		} else if (tab == 3) {
			comps.add(openKey);
			comps.add(phraseKey);
			comps.addAll(phraseFields);
		} else {
			comps.addAll(soundSliders);
		}
	}

	private void setAspectPreset(String preset) {
		var window = MinecraftClient.getInstance().getWindow();
		int width = Math.max(640, window.getWidth());
		int height = switch (preset) {
			case "16:9" -> Math.round(width * 9f / 16f);
			case "4:3" -> Math.round(width * 3f / 4f);
			case "21:9" -> Math.round(width * 9f / 21f);
			default -> window.getHeight();
		};
		if (!"Custom".equals(preset)) {
			windowWidth.setText(Integer.toString(width));
			windowHeight.setText(Integer.toString(Math.max(480, height)));
		}
	}

	private void applyWindowSize() {
		var window = MinecraftClient.getInstance().getWindow();
		if (window.isFullscreen()) {
			NotificationManager.push("Window size", "Switch to windowed mode first", Icons.VISUALS);
			return;
		}
		try {
			int width = Integer.parseInt(windowWidth.getText());
			int height = Integer.parseInt(windowHeight.getText());
			if (width < 640 || width > 7680 || height < 480 || height > 4320) {
				throw new NumberFormatException();
			}
			window.setWindowedSize(width, height);
			NotificationManager.push("Window size applied", width + " x " + height, Icons.VISUALS);
		} catch (NumberFormatException exception) {
			NotificationManager.push("Invalid resolution", "Use width 640-7680 and height 480-4320", Icons.VISUALS);
		}
	}

	@Override
	public String title() {
		return "Settings";
	}

	@Override
	public void onShow() {
		super.onShow();
		rebuild();
	}

	@Override
	protected int reflow(int top) {
		int usable = w - 10;
		tabs.bounds(x, top, 170, 20);
		int cy = top + 30;
		if (tab == 0) {
			for (Slider s : new Slider[]{guiScale, animSpeed, glow, transparency, radius}) {
				s.bounds(x, cy, usable, 26);
				cy += 32;
			}
			cy += 4;
			for (Toggle t : new Toggle[]{guiAnim, glowOn, lowPerf, fpsOpt, notif, lyricsOn}) {
				t.bounds(x, cy, usable, 24);
				cy += 28;
			}
			for (Slider s : new Slider[]{hudScale, notifSec, musicVol}) {
				s.bounds(x, cy, usable, 26);
				cy += 32;
			}
			cy += 6;
			reset.bounds(x, cy, usable, 22);
			return cy + 30;
		}
		if (tab == 1) {
			aspectRatio.bounds(x, cy, usable, 22);
			int half = (usable - 6) / 2;
			windowWidth.bounds(x, cy + 30, half, 20);
			windowHeight.bounds(x + half + 6, cy + 30, half, 20);
			applyResolution.bounds(x, cy + 58, usable, 22);
			return cy + 94;
		}
		if (tab == 2) {
			presOn.bounds(x, cy, usable, 24);
			badgeOn.bounds(x, cy + 28, usable, 24);
			capeOn.bounds(x, cy + 56, usable, 24);
			url.bounds(x, cy + 108, usable, 20);
			nevavis.config.NevaVisConfig cfg = ConfigManager.get().data();
			if (!url.getText().equals(cfg.presenceUrl)) {
				cfg.presenceUrl = url.getText().trim();
				nevavis.presence.PresenceManager.resetTimer();
			}
			return cy + 170;
		}
		if (tab == 3) {
			openKey.bounds(x, cy, usable, 26);
			phraseKey.bounds(x, cy + 32, usable, 26);
			cy += 66;
			for (SearchBar phraseField : phraseFields) {
				phraseField.bounds(x, cy, usable, 20);
				cy += 26;
			}
			return cy + 10;
		}
		for (Slider slider : soundSliders) {
			slider.bounds(x, cy, usable, 26);
			cy += 32;
		}
		return cy + 10;
	}

	@Override
	protected void renderBody(DrawContext c, double mx, double my, float dt) {
		if (tab == 2) {
			Gfx.text(c, "Worker URL (see server/README.md):", x + 4, url.y - 12, ThemeManager.dim());
			Gfx.text(c, nevavis.presence.PresenceManager.statusText(), x + 4, url.y + 26, ThemeManager.accent());
		}
		if (tab == 3) {
			Gfx.text(c, "Click the field, then press a key. Esc cancels.", x + 4, openKey.y + 34, ThemeManager.dim());
			List<String> phrases = ConfigManager.get().data().quickPhrases;
			for (int i = 0; i < phraseFields.size(); i++) {
				phrases.set(i, phraseFields.get(i).getText());
			}
		}
	}
}
