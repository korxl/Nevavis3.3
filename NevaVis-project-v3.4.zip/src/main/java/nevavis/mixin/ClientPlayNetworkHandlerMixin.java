package nevavis.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.entity.EntityStatuses;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import nevavis.modules.visuals.TotemAnimationModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Listens for the vanilla totem status on the local player only. */
@Mixin(ClientPlayNetworkHandler.class)
public abstract class ClientPlayNetworkHandlerMixin {
	@Inject(method = "onEntityStatus", at = @At("HEAD"))
	private void nevavis$totemAnimation(EntityStatusS2CPacket packet, CallbackInfo ci) {
		MinecraftClient client = MinecraftClient.getInstance();
		if (client.player != null && client.world != null
				&& packet.getStatus() == EntityStatuses.USE_TOTEM_OF_UNDYING
				&& packet.getEntity(client.world) == client.player) {
			TotemAnimationModule.trigger();
		}
	}
}