package nevavis.mixin;

import net.minecraft.client.render.WorldRenderer;
import nevavis.modules.visuals.BlockOverlayModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

/** Changes only the color of the vanilla-selected block outline. */
@Mixin(WorldRenderer.class)
public abstract class WorldRendererMixin {
	@ModifyArg(
			method = "renderTargetBlockOutline",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/client/render/WorldRenderer;drawBlockOutline(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumer;Lnet/minecraft/entity/Entity;DDDLnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/BlockState;I)V"
			),
			index = 8
	)
	private int nevavis$blockOverlayColor(int vanilla) {
		return BlockOverlayModule.color(vanilla);
	}
}