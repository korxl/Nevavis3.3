package nevavis.mixin;

import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import nevavis.config.ConfigManager;
import nevavis.hud.HudAnimations;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Скрывает ванильный прицел, когда включён прицел NevaVis. */
@Mixin(InGameHud.class)
public abstract class InGameHudMixin {
	@Inject(method = "renderHotbar", at = @At("HEAD"))
	private void nevavis$hotbarStart(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
		HudAnimations.beginHotbar(context);
	}

	@Inject(method = "renderHotbar", at = @At("RETURN"))
	private void nevavis$hotbarEnd(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
		HudAnimations.end(context);
	}

	@Inject(method = "renderChat", at = @At("HEAD"))
	private void nevavis$chatStart(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
		HudAnimations.beginChat(context);
	}

	@Inject(method = "renderChat", at = @At("RETURN"))
	private void nevavis$chatEnd(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
		HudAnimations.end(context);
	}

	@Inject(method = "renderPlayerList", at = @At("HEAD"))
	private void nevavis$tabStart(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
		HudAnimations.beginTab(context);
	}

	@Inject(method = "renderPlayerList", at = @At("RETURN"))
	private void nevavis$tabEnd(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
		HudAnimations.end(context);
	}

	@Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
	private void nevavis$hideCrosshair(CallbackInfo ci) {
		if (ConfigManager.get().data().crosshair.enabled) {
			ci.cancel();
		}
	}
}
